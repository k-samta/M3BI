insert into user values(1, 101, 'User1');
insert into user values(2, 102, 'User2');
insert into user values(3, 103, 'User3');
insert into user values(4, 104, 'User4');

insert into hotel(id, status, price) values(10, 'AVAILABLE', 1000);
insert into hotel(id, status, price) values(11, 'AVAILABLE', 1005);
insert into hotel(id, status, price) values(12, 'AVAILABLE', 1006);

insert into bonus values(101, 1000);
insert into bonus values(102, 1002);
insert into bonus values(103, 1003);
insert into bonus values(104, 1006);

