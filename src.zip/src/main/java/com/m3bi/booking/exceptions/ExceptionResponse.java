package com.m3bi.booking.exceptions;

public class ExceptionResponse extends Exception {
	
	String message;
	

	public ExceptionResponse(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}


	@Override
	public String toString() {
		return "ExceptionResponse message=" + message ;
	}
}
