package com.m3bi.booking.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
public class PendingApproval {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	
	@NotNull
	int userId;
	
	@NotNull
	int hotelId;
	
	@NotNull
	@Min(value=0)
	int price;
	
	@NotNull
	String status;
	
	public PendingApproval() {
		// TODO Auto-generated constructor stub
	}

	public PendingApproval(int userId, int hotelId, int price, String status) {
		super();
		this.userId = userId;
		this.hotelId = hotelId;
		this.price = price;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "PendingApproval [id=" + id + ", userId=" + userId + ", hotelId=" + hotelId + ", price=" + price
				+ ", status=" + status + "]";
	}
}
